This mod was changed by me (narrowcwyfe)

all I did was rehardpoint this mod and include the ship along with it, everything else I kept original

***Credits***

- A a fellow modder named "Tardis": for creating and fixing the transphasic torpedo technology, without him this ship would not have been possible!!!
- Also CGI for some parts of the model - the original one looked too skinny!

Known issues:

- Activating the plating with the Plating button instead of the Mvam may leave your ship in the dark for a few seconds.
PLEASE NOTICE THIS IS A WIP MOD, WE ARE STILL MISSING SOME THINGS!


