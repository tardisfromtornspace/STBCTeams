# Yes, Plugins is a module. -Dasher42
