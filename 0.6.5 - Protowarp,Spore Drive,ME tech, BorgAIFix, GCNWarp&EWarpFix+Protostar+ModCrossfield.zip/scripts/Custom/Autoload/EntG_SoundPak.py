#####  Created by:
#####  Bridge Commander Universal Tool


import App
import Foundation


Foundation.SoundDef("sfx/Weapons/25th_Century_phaser2a.wav", "Type_XIV_Phaser Start", 1)
Foundation.SoundDef("sfx/Weapons/25th_Century_phaser2b.wav", "Type_XIV_Phaser Loop", 1)
Foundation.SoundDef("sfx/Weapons/PicPhoton.wav", "PicPhoton", 1)