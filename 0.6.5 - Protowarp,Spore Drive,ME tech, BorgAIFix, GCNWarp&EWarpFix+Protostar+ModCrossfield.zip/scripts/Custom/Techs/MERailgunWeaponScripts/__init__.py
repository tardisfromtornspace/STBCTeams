###############################################################################
#	Filename:	__init__.py
#	
#	Confidential and Proprietary, Copyright 2000 by Totally Games
#	
#	This file is needed so that Python recognizes the Hardpoints directory
#	as a package.
#	
#	Created:	9/4/00 -	Erik Novales
###############################################################################
