1.1 DESCRIPTION :

Bones proudly presents : Turian Frigate 
Turian Frigates are the backbone of whole Turian fleet, they are also part of the Citadel Defense Fleet. Heavily armed and armored, these ships can stand to the challenge even with ships that are twice the size. This ship comes with some serious firepower and additional hangar bay holding 10 Turian Fighters.


1.2 TECHNICAL DATA :
	
-2x Javelin Disruptor Torpedo (1 launcher per side = 5 torpedoes per 1 launcher)
-6x Mass Accelerator cannons
-2x Heavy Mass Accelerator cannons	
-10x Turian Interceptor Fighter
-Heavy Turian armor


1.3 MOD INFO :

Model and textures were extracted from Mass Effect and converted for Bridge Commander, only glows and specaular highlights were altered to suit BC graphic engine so the ship appears the same as it was in ME. Hardpoints are entirely fan created mainly due to lack of any info about possible weapons count or placement. 

1.4 REQUIREMENTS :

Bridge Commander Patch v1.1 (obviously neede for anything to work : http://bridgecommander.filefront.com/file/Bridge_Commander_Patch;2374
Foundation (can be found in BCUT) - needed for any mod to run : http://bridgecommander.filefront.com/file/Bridge_Commander_Universal_Tool;106619
NanoFX 2.0 beta - needed for blinking lights : http://bridgecommander.filefront.com/file/NanoFX_Beta;23469
Recommended :
Kobayashi Maru Mod v1.0 / 1.2 beta - Contains all above mods.


1.5 INSTALATION INSTRUCTION:

1. For best safe precaution always make buckup folder of SCRIPTS folder in your Bridge Commander (this is to avoid any problems with mod, so you can always restore your previous scripts)
2. Copy and paste all folders to the Bridge Commander root directory.
3. Run the game, ship will appear in new ships group called 'Mass Effect ships' -> Turian fleet -> Turian Frigate and Turian Fighter 


1.6 CREDITS :

Bioware ------------------------------------------ Mass Effect 1&2 ; Turian Frigate and Fighter meshes
Activision/Totally Games ------------------------- For Bridge Commander
Paramount and Gene Roddenberry ------------------- For Star Trek
dr_mccoy 11/Bones -------------------------------- Model conversion

BETA TESTERS :

TiqHud
Killallewoks
FarShot
Shadowknight1

SPECIAL THANKS TO BRIDGE COMMANDER CENTRAL COMMUNITY AND BETA TESTERS FOR ALL FEEDBACK AND SUPPORT.

Contact me at 1701abcde@gmail.com or PM me at http://www.bc-central.com/forums

1.7 DISCLAIMER :

This mod was scanned with ESET Nod 32 and AVIRA for viruses and fully tested on Bridge Commander v1.1 (Custom build) and BC v1.1 with latest Kobayashi Maru mod before it was released. I take no responsibility for any damage this mod may cause to your system before, during, or after it has been installed.

Copyright and Distribution Permissions
--------------------------------------
THIS MODEL(S) IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY Activision
TM & (C) INTERPLAY & PARAMOUNT PICTURES.

Copyright notices:

Star Trek, Bridge Commander, Star Trek: Deep Space Nine, Star Trek: The Next Generation,
Star Trek: Voyager (and the various logo devices used in them) are copyright Paramount Pictures,
as are the characters, related images, and sound from the productions.