#####  Created by:
#####  Bridge Commander Universal Tool


import App
import Foundation


Foundation.SoundDef("sfx/Weapons/Protostar_Phaser2.wav", "Protostar_Phaser Start", 1)
Foundation.SoundDef("sfx/Weapons/Protostar_Phaser2.wav", "Protostar_Phaser Loop", 0.6)
Foundation.SoundDef("sfx/Weapons/Fed_Photon1.wav", "ProtostarFedPhoton1", 1)