Model: Crossfield class

Models: Ported from Star Trek: Adversaries (https://store.steampowered.com/app/815040/Star_Trek_Adversaries/)
Torpedoes: Zambie Zan (alexandre.marques@gmail.com)
Phasers: Wiley Coyote (michaelwileyart@gmail.com)
BC Conversion: That Guy...Brian (trekker12@hotmail.com)
Hardpoints: That Guy...Brian

Enjoy!

P.S. Reccommended model scaling for hardpoint editing is 0.0098!

