=== Changelong ===
1.0.0 - Release of the mod


- First of all, thank you, SCI-FI KING for giving me the Berlin mod.
- scripts: the original ones for the THGBerlin
- model modified by Alex SL Gato.

==What does this mod include==
An improved TNG Berlin class, with a better model and with a bug making it have less shield generator power than it should.
===Required mods===
* Kobayashi Maru (the most modern the best).
===Optional mods==
* Recommended to have the original Berlin class mod pack
=== How to install ===
1º Ok, first of all, just in case, backup your STBC. After that please verify you have the mods above installed.

2º After that, just unzip the files into your STBC folder, say "yes" to overwrite all the files.

3º Enjoy!