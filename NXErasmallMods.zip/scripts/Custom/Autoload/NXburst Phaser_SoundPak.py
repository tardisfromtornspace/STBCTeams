#######################################################################################
#  Custom Weapon Sound Plugin                                                         #
#  Created by BC - Mod Packager                                                       #
#  Date: 4/15/2005                                                                    #
#######################################################################################
#                                                                                     #
import Foundation
import App
#                                                                                     #
#######################################################################################
#                                                                                     #
Foundation.SoundDef("sfx/Weapons/NX phaser start burst.wav", "NXburst Phaser Start", 1)
Foundation.SoundDef("sfx/Weapons/NX phaser start burst2.wav", "NXburst Phaser Loop", 1)
#                                                                                     #
#######################################################################################
