#######################################################################################
#  Custom Weapon Sound Plugin                                                         #
#  Created by BC - Mod Packager                                                       #
#  Date: 05.09.2002                                                                    #
#######################################################################################
#                                                                                     #
import Foundation
import App
#                                                                                     #
#######################################################################################
#
Foundation.SoundDef("sfx/NXEngines.wav", "NXEngines", 1)
Foundation.SoundDef("sfx/Weapons/Phase Disrupers.wav", "Phase Disrupers", 1)                                                                                     #
Foundation.SoundDef("sfx/Weapons/NX Torpedo.wav", "NXtorpedo", 1)
#                                                                                     #
#######################################################################################
