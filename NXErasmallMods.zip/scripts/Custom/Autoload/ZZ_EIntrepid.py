import Foundation
import App

Foundation.SoundDef("sfx/Weapons/EPhaser start.wav", "EPhaser Start", 0.5)
Foundation.SoundDef("sfx/Weapons/EPhaser loop.wav", "EPhaser Loop", 1)
Foundation.SoundDef("sfx/Weapons/EPhotonic.wav", "EPhotonic", 1)
