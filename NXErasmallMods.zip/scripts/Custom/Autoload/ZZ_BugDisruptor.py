import Foundation
import App

Foundation.SoundDef("sfx/Weapons/ZZ_BugDisruptor.wav", "BugDisruptor", 1)
