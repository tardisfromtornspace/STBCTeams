import Foundation

#############################################################################################
#                                                                                           #
#  This Section Handles the 'Repair Destroyed Systems' mutator,                             #
#                                                                                           #
#                                                                                           #
#                                                                                           #
#############################################################################################

mode = Foundation.MutatorDef("Repair Destroyed Systems")