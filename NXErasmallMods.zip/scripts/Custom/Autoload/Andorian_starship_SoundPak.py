#######################################################################################
#  Custom Weapon Sound Plugin                                                         #
#  Created by BC - Mod Packager                                                       #
#  Date: 03/07/2005                                                                    #
#######################################################################################
#                                                                                     #
import Foundation
import App
#                                                                                     #
#######################################################################################
#                                                                                     #
Foundation.SoundDef("sfx/Weapons/ANdisruptor_a.wav", "An Phaser Start", 1)
Foundation.SoundDef("sfx/Weapons/ANdisruptor_b.wav", "An Phaser Loop", 1)
#                                                                                     #
#######################################################################################
