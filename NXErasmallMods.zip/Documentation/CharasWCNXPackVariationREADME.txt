I've tried to find all the readmes about the original mods these pack modifies, specially the WC NX Pack and the Xindi Aquatic, Insectoid and 22nd Century Tholian ship.

I've personally asked for permission from WileyCoyote via e-mail and while I didn't get a respose, a friend who is in contact with them (THE-SCI-FI-KING) SAID "He said along you give proper credit he is fine".

==CHANGES DONE ON THIS MOD==
This mod aims for a more canon ship, that is, power-level-wise and tech-level wise. As such:
- Added new AblativeArmour variation, will reduce damage consideraly but some damage will bleed through.
- Reduced shield strength on most ships to a token value (equivalent to pouring more power to polarizing the hull).
- Reduced overall weaponry power.
- Increased burn and hole values for some ships. Now it'll take a bit longer to make a hole on those ships.
- Added warp speed limits.
- Added some extra "lore" to the descriptions.

Requirements------------------

Tested in Kobayashi Maru ***recommended***
Submenu mod **also in KM**
NanoFx 2.0 beta **also in KM**
ID map swapping **also in KM**
Foundation Technologies **also in most current KM versions**

Bugs--------------------------

None that I've found, but if you find anything (missing files, buggy behaviour) please tell us.