#####  Created by:
#####  Bridge Commander Universal Tool


import App
import Foundation


Foundation.SoundDef("sfx/Weapons/Metreon_Pulsewave_Torpedo.wav", "Pulsewave", 1)
