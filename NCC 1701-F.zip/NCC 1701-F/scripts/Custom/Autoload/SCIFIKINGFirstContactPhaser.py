#####  Created by:
#####  Bridge Commander Universal Tool


import App
import Foundation


Foundation.SoundDef("sfx/Weapons/First Contact Phaser A.wav", "FirstContactPhaser Start", 1)
Foundation.SoundDef("sfx/Weapons/First Contact Phaser B.wav", "FirstContactPhaser Loop", 0.95)
