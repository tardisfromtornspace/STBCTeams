#####  Created by:
#####  Bridge Commander Universal Tool


import App
import Foundation


Foundation.SoundDef("sfx/Weapons/SCIFIPhotonTorp.wav", "SCIFIPhotonTorp", 1)
