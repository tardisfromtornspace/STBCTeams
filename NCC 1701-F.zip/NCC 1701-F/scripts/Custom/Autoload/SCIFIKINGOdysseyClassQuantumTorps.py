#####  Created by:
#####  Bridge Commander Universal Tool


import App
import Foundation


Foundation.SoundDef("sfx/Weapons/Odyssey Class Quantum Torps.wav", "OdysseyClassQuantumTorps", 1)
