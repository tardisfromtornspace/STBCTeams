#####  Created by:
#####  Bridge Commander Universal Tool


import App
import Foundation


Foundation.SoundDef("sfx/Weapons/burstbeam_a.wav", "BurstBeam Start", 0.98)
Foundation.SoundDef("sfx/Weapons/burstbeam_b.wav", "BurstBeam Loop", 0.98)

Foundation.SoundDef("sfx/Weapons/N_Future_Lance_start.wav", "Future_Lance_Phaser Start", 2.5)
Foundation.SoundDef("sfx/Weapons/N_Future_Lance_loop.wav", "Future_Lance_Phaser Loop", 2.5)

Foundation.SoundDef("sfx/Weapons/MarsShipyardsTorpedo.WAV", "MarsTorpedo", 1)

Foundation.SoundDef("sfx/Weapons/NXBeoPulseQuantum.wav", "NXBeoPulseQuantum", 1)

Foundation.SoundDef("sfx/Weapons/SFRD_Weapons/SFRD_24th_QuantumTorpedo3_FED.wav", "QuantumTorp", 1)

Foundation.SoundDef("sfx/Weapons/QuantumXII.wav", "QuantumXII", 1)
