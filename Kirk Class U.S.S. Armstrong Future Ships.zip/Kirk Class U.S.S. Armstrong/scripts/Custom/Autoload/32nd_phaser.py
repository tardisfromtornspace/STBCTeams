#####  Created by:
#####  Bridge Commander Universal Tool


import App
import Foundation


Foundation.SoundDef("sfx/Weapons/N_32nd_Century_phaser.wav", "32nd_phaser Start", 1)
Foundation.SoundDef("sfx/Weapons/N_32nd_Century_phaser.wav", "32nd_phaser Loop", 1)
