#####  Created by:
#####  Bridge Commander Universal Tool


import App
import Foundation


Foundation.SoundDef("sfx/Weapons/GalaxyDS9_phaser1.wav", "DJPhaser Start", 1)
Foundation.SoundDef("sfx/Weapons/GalaxyDS9_phaser2.wav", "DJPhaser Loop", 1)
