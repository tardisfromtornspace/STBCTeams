#####  Created by:
#####  Bridge Commander Universal Tool
import App
import Foundation
Foundation.SoundDef("sfx/weapons/MassAccelerator1.wav", "MassAccelerator1", 1)
Foundation.SoundDef("sfx/weapons/MassAcceleratorXXL.wav", "MassAcceleratorXXL", 1)
Foundation.SoundDef("sfx/weapons/DM_JavelinTorpedo.wav", "JavelinTorpedo", 1)
Foundation.SoundDef("sfx/weapons/FigMassAccel.wav", "FigMassAccel", 1)

