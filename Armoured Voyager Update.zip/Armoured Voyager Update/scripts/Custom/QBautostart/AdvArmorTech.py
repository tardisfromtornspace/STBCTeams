# No longer used
def init():
	print("AdvArmorTech: this mod got moved to scripts/Custom/Techs/AdvArmorTechThree.py");

