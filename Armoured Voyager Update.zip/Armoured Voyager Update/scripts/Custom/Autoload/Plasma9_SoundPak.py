import Foundation
import App

Foundation.SoundDef("sfx/Weapons/Plasma9.WAV", "Plasma1", 1.0)