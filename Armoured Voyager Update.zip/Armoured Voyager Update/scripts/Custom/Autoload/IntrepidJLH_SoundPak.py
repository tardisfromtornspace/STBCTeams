import Foundation
import App

Foundation.SoundDef("sfx/Weapons/VoyPhaserBJLH.wav", "Intrepid Phaser Loop", 1)
Foundation.SoundDef("sfx/Weapons/VoyPhaserAJLH.wav", "Intrepid Phaser Start", 1)
Foundation.SoundDef("sfx/Weapons/VoyTorpJLH.wav", "VoyTorpJLH", 1)
