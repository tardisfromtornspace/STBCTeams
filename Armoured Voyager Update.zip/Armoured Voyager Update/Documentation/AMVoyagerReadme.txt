Name: Modified armored voyager one(MVAM)

Description:
This is a modified version of Voyager 0ne.  The ship's transphasic torpedo hardpoint has been slightly changed along with the transphasic torpedo.
The Torpedo was changed to a modified 'Transphasic_Plasma' (I modified the colours and the strength to make it more canon to the Final episode of 
voyager when it was destroying cubes in 2 shots.... muahahahaha).  This torpedo is most likely the most powerful torpedo on Filefront as it can destroy a 
borgpack borg tactical cube in 2 hits.  I strongly suggest that this NOT be made a multiplayer ship/torpedo because of the radical power of the torpedo.
The ship's textures and model was not altered.  When you activate the armour (via MVAM) the torpedo 'T Plasma' is your transphasic torp.  And it is loaded
first above all other torps so all you have to do is fire.  The torpedo is not accessable without the armour.
Unfortunately MVAM is not compatable with QBR so you wont be able to MVAM in QuickBattleGame.
But standard QB is fully compatable with MVAM.

Installation:
1. copy the data, scripts, and sfx folders into your bridge commander root folder.
2. launch bridge commander.
3. give the toughest borg cube you can find the Butt-kicking of the century.

Requirements:
NanoFXV2 for blinkers and such.
Mvam Infinite
Future Technologies 2.0 plugin
Foundation
BC patch 1.1
BCMI
BCMP

Credits:
Ein-Kun: For the Transphasic torpedo.

The following credits are for the ship builders:

Hardpoints: Laurelin    rework   by MRJOHN

Textures :Rick Knox ,MRJOHN,Spencer4Hire

Mesh : Rick Knox  rework  by  : MRJOHN

AIs : SDK , MRJOHN ,

Torpedos , Tex : MRJOHN ,Laurelin

Icons : MRJOHN

SFX : MRJOHN, SFC3 ,Laurelin

Weapons: Laurelin ,MRJOHN

you need NanoFXV2 for the lights or you can delete the lights in the hp in MPE

Mvam Infinite and AI: Sneaker98,AI plugin MRJOHN

Mvam  script up or plugin : Adonis

Future Technologies 2.0 plugin , Armor : Edtheborg ,plugin MRJOHN

ATP ,Armor : USS Apollo

SFX : ART OF WAR ,MRJOHN ,Apollo,P81,SFC3, Sneaker98

Endgame Voyager SFC3 Retexturing : Spencer4Hire ,Wildcard
 
Launching Framework/New Technology Sytem : SimRex, plugin MRJOHN

Carrier : Evan Light , and for the launcher you need the (deltaflyer , Aero Shuttle)

Dark Gunman BC Improvement Pack for the Torpedo Tex



Copyright and Distribution Permissions

--------------------------------------
THIS MODEL(S) IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY Activision
 TM & (C) INTERPLAY & PARAMOUNT PICTURES.

Copyright notices: 

Star Trek, Bridge Commander, Star Trek: Deep Space Nine, Star Trek: The Next Generation,
Star Trek: Voyager (and the various logo devices used in them) are copyright Paramount Pictures,
as are the characters, related images, and sound from the productions. 

If you must add this ship or any weapons, textures or models to your own mod please ask permission 
of myself at: nathancox5@netscape.net, and the author of the ship at: rknox@maddocsoftware.com


