This mod was changed by me (narrowcwyfe)

all I did was rehardpoint this mod and include the ship along with it, everything else I kept original

***Credits***

- A a fellow modder named "Tardis": for creating and fixing the transphasic torpedo technology, without him this ship would not have been possible!!!
- Also CGI for some parts of the model - the original one looked too skinny!

Known issues:

- when using MVAM, the armoured version of voyager appears to not load the torpedo scripts properly, 
leading the ship to only have one torpedo per torpedo tube, and not 35, as instructed.


