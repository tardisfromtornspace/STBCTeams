COLUMBIA  CLASS - BATTLESTAR
STARHOUND CLASS - FIGHTER/INTERCEPTOR

General Stuff:
File		BSG_Battlestar_V.0.9.zip
Ship/s		Colonial Battlestar Ver 0.9
Meshs 		MadJohn		SFCommand Conversion --- See Original Read me's.
Hardpoints	Madjohn		Finaly!!!!! Weeks of blood, sweat and caffine.
Carrier File	MadJohn
SFX		Nine of Nine	PulsePhaserJLH.wav from Defiant V1.5

Requirments:

ST.Bridge Commander 	Ver 1.1		With Foundation Plugin	by Dasher42
Launching Framework	Ver 051102b	With New Tech 		by sleight42
Return Shuttles		Ver 0.6	or higher???			by Defiant

Thankx to:		The Few who Helped, Genty for the link, BlackRook32 and elminster for their suggestions in doting the I's and T's.


Known Bugs:

Textures		Bit Pants Realy, Looks OK but!!
Damage Textures		Definitly needs some new ones of these.
Weapons			Weapons fire looks too large in relation to fighter models.
Launch Tubes		Not available in QBGame ????
Return Shuttles		Don't quite make it into the hangers, not sure why.



Other Stuff

Weapons Stuff -	Dont give me grief about the Phasers(Pulsar Lasers(NO they are NOT Lasers)) Damage level. These weapons were designed to 'Take Down' the heavely armoured Basestars, so when it blows six colours of s*!t out of your Sov dont come running to me crying, It is powerfull but has a long recharge rate so "its about cannon as you get in BSG". Besides I have only Hardpointed HALF the TurboLasers and Launch Tubes this ship has to compensate. STOP Thinking 'Starship' this is more on par with an ISD, but with better weapons coverage.

Tactics:	Avoid direct engagement unless necessary, let your fighters do the work. The exception is if your enemy has a Carrier Class vessel. In this case KILL THE CARRIER FAST. For close in defense switch targets often to discourage them from getting too close.
		