Battlestar Galactica Fleet Pack.

For help contact daverussell_345@fsmail.net, but please read the rest of this first if you have problems!

Here we have most of the colonial fleet ships from BSG, as well as the cylon ships too. We've tried to balance the sizes and
HP's as accurately as we can, so hopefully they're pretty accurate. There may be a few of the ships that have been seen in 
the show that aren't in here, but we've added all the ones made by Coxxon, as well as a couple of others. 

Included in the pack are the following ships;-

Colonial Ships;

Battlestar Galactica (Mvam) - You need to retract the pods using the Mvam mode before being able to go to warp, as the
           version with the pods deployed doesn't have a jump system included. There is also a shuttle launching script that
           allows you to launch up to 20 vipers, with mostly Mark 2 vipers, and a few Mark 7's.

Battlestar Pegasus - Like the Galactica, this also has a shuttle launch script to allow the launching of vipers, although
           Pegasus has Mark 7 vipers only and there are 40 of them.

Viper (Mark 2 and Mark 7) - Both versions of the viper are included, and both are highly maneuverable. To keep them accurate
           they can turn end-to-end in no time, but they slow down dramatically for a few seconds before accelerating again
           on the hard turns. This makes for some very fun close-quarters dogfights. There are 2 missiles on each viper, and
           quite a few "Dead" missiles that are invisible and cause no damage. These were included because the AI turns to
           attack far more often if the ship has torpedoes.

Blackbird Stealth-Fighter - This is the stealth ship that was built on Galactica and seen only a few times before it was
           destroyed. It's more difficult to control than the standard vipers to reflect Starbuck's test flight in season 
           2. Unlike the vipers, it has a jump-drive included and can be a lot of fun when used with the silent running mod,
           because then it can actually be used as a stealth ship.

Raptors (SAR, Escort and Assault) - There are 3 versions of the raptor included. The first is the 'search and rescue' raptor
           which carries no weapons. The second is the 'escort' version which has 8 missiles, and was designed to escort the
           SAR raptor into dangerous territory. Thirdly we have the 'assault' raptor, as seen in the season 3 episode 
           "Exodus - Part 2". This version was fitted with large missile batteries on either side, and can inflict far more 
           damage.

Defender - This ship has been seen a few times in the show, and was part of the defensive patrol fleet orbiting New Caprica
           at the end of season 2. It has a few canons on the hull that provide almost complete cover, but it is far less 
           powerful than the battlestars. It may have been designed as a support ship for the larger military vessels.

Colonial 1 - The presidents ship, small enough to fit into Galactica's landing bays. Designed as a passenger liner it has no
           weapons or defences of any kind.

Shuttle - The short range shuttle often seen transporting people around the fleet.

Astral Queen - The large prison transport. This vessel is very slow and sluggish, so it'll need a lot of cover.

Passenger Liners - There are 6 different versions of the passenger liners, none of which have any weapons.

Botanical cruiser - This ship has been seen many times with the fleet, and is no doubt responsible for growing much of the 
           fleet's food.

Cloud 9 - This is the large tourist ship with an artificial bio-dome that was nuked right at the end of season 2. It's a
           very large ship, and an easy target.

Tylium Refinery - The ship that provides fuel for the entire fleet, it should make a pretty big explosion when it goes up, 
           so shoot it from a safe distance.

Celestra - This is one of the ships that was kept from the original series. It doesn't seem to have a specific function in 
           the show, although there was another identical ship called the "Striker" seen in the episode "Home - Part 2".

Colonial Movers - The transport ship that was used to conceal the second attack squadron of vipers in the episode "Hand of
           God". This is another of the ships taken and improved from the original series.

Tube Tanker - This tanker was seen in one of the earliest episodes of the new series "Water", and appeared to be a small 
          tanker vessel, but has not really been seen since.

Space Park - This is the ship with the very big bright wheel at the back. From what we can tell it's a pleasure cruiser with
           an artificial bio-dome similar to Cloud 9.

Mining Ship - A couple of these ships have been seen around the fleet, one was seen performing mining operations in the 
           episode "Scar".

Mobile Shipyard - The shipyard is designed as a mobile repair facility and construction platform capable of repairing or 
           constructing small vessels.

Gemini Transport - Another small freighter.

Gemini Traveller - One of several small, personal cruisers not much bigger than the shuttles. At least 3 of them were seen 
           with the small fleet that broke away to return to Kobol at the beginning of season 2.


Cylon Ships;

Basestar - The Cylon's most powerful ships. The vessels can be a match for Galactica in a 1-on-1 battle, but when they
           outnumber the battlestar's they usually come out on top. They have 6 Nuke launchers evenly spaced around the ship
           and standard missile launchers giving almost all round coverage. The missiles have a limited range because of 
           their speed, but excellent tracking ability. This ship also has a shuttle launching script like the battlestars 
           and can launch a large amount of raiders at will.

Raider - The standard raider is very fast and deadly, and highly maneuverable. Like the vipers it has 2 forward canons and 
           missile launchers, although it can carry far more missiles. I haven't included the nukes that they carried in the
           mini-series as they took all the fun out of the dogfights.

Heavy raider - The heavy raider is more heavily armoured than the standard raider and has 6 forward canons instead of 2, as
           well as a couple of missile launchers. Because it is bigger and more heavily armoured it is slower than the 
           standard raiders and can be hit more easily.


Credits;
     
All the credits for the original models except for the Blackbird Fighter go to Coxxon, although myself (Dave975) and MadJohn
have added a few improvements to them, such as afterburners, glows and engine textures. The HP's were done by myself and
MadJohn. The Blackbird model was done by me since it wasn't included with Coxxon's models, and DKealt was kind enough to add
the textures to it. Sfx were all done by me.


Known Bugs;

Since the models are quite large compared to most ships, and they weren't originally made specifically for BC, many don't 
take visible damage at all. Smaller ships such as the fighter's take damage just fine, but the battlestar's and some others
don't

WARNING - The basestars will slow the game down A LOT if you play with damage textures on. If you want a smooth battle turn
them off, otherwise every hit they take will slow the game.


Other Info;

Before anyone complains, these ships are not balanced against anything other thaneach other. Please don't e-mailing me 
telling me a Sovereign took it out in 30 seconds. They have no shields and are barely able to stand up to nukes, let alone
anti-matter warheads.

Thanks to lost_Jedi the missiles all have smoke trails on them which makes them look much cooler.

All plugin files are included and the ships have been put into submenus under the menu of BSG Ships. There is no need to use
BCMP or anything like that.


Requirements;

Since the smoke trails were based on the plasma streams in nanofx, NanoFX2.0B may be required, i'm not really sure.
To get the submenus organised properly you will need version 3.0 of the submenu mod or higher.
Although it's not a requirement, it is fun to have the silent running mod for the blackbird.


Installation Instructions;

With the Stargate pack there seemed to be some confusion over this, so this time i will spell it out as simply as i can.

Step 1 - unzip the pack and open your root BC directory.
Step 2 - copy and place the files from the pack into your BC directory.
Step 3 - since the plugin files are included there is no need to do anything else. As long as you have the foundation 
         installed and your mutators on they should appear under BSG Ships in quickbattle

For those of you who don't know where to get the foundation or what mutators are, please consult the forums before thinking
about e-mailing me. I get tired of answering such simple questions that have been answered on miltiple forum threads many,
many times already.