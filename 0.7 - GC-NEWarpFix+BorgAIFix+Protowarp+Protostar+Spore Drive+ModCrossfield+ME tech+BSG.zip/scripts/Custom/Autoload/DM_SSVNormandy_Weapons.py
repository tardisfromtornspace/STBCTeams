#####  Created by:
#####  Bridge Commander Universal Tool


import App
import Foundation


Foundation.SoundDef("sfx/Weapons/GARDIAN_a.wav", "GARDIAN Start", 1)
Foundation.SoundDef("sfx/Weapons/GARDIAN_b.wav", "GARDIAN Loop", 1)
Foundation.SoundDef("sfx/Weapons/DM_JavelinTorpedo.wav", "JavelinTorpedo", 1)
Foundation.SoundDef("sfx/Weapons/DM_NormandyCannon.wav", "NormandyCannon", 1)
Foundation.SoundDef("sfx/Weapons/MESpinalMassAccelerator.wav", "MESpinalMassAccelerator", 1)