import Foundation
import App

Foundation.SoundDef("sfx/Tardis_mat1.wav", "tardisengines Start", 1)
Foundation.SoundDef("sfx/Tardis_hum.wav", "tardisengines Loop", 1)
Foundation.SoundDef("sfx/Tardis_mat1.wav", "tardisenginestwo", 1)
Foundation.SoundDef("sfx/Tardis_demat1.wav", "tardisenginesthree", 1)