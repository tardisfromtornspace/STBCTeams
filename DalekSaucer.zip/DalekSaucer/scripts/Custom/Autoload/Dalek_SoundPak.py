#####  Created by:
#####  Bridge Commander Universal Tool


import App
import Foundation


Foundation.SoundDef("sfx/Weapons/DalekShot1.wav", "DalekShipShot1", 1)
Foundation.SoundDef("sfx/Weapons/DalekMissile.wav", "DalekMissile", 1)
#Foundation.SoundDef("sfx/Weapons/DalekShot.wav", "DalekShot1", 1)
#Foundation.SoundDef("sfx/Weapons/DalekExterminate.wav", "DalekExterminate", 1)

#Foundation.SoundDef("sfx/Weapons/DalekEngines.wav", "DalekEngines", 1)
