#####  Created by:
#####  Bridge Commander Universal Tool


import App
import Foundation


Foundation.SoundDef("sfx/Weapons/N_Reflux_Quantum.wav", "Reflux_Quantum", 2)
