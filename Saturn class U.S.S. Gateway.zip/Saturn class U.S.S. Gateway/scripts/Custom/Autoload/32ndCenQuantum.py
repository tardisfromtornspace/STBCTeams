#####  Created by:
#####  Bridge Commander Universal Tool


import App
import Foundation


Foundation.SoundDef("sfx/Weapons/N_32ndCenturyQuantum.wav", "32ndCenQuantum", 2)
